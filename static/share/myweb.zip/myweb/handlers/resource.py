import os
import json
from tornado.web import RequestHandler
from mariadb.test import createart


class ResourceHandler(RequestHandler):
    def get(self):
        #print('ResourceHandler', self.request.uri)
        try:
            self.write(open('static' + self.request.uri, 'rb').read())
        except FileNotFoundError:
            self.write_error(404)

    def write_error(self, status_code, **kwargs):
        if status_code == 404:
            self.write('404 Not Found')
        else:
            self.write('error:' + str(status_code))


class FileHandler(RequestHandler):
    def get(self):
        self.render('upload.html')

    def post(self):
        ret = {'result': 'OK'}
        file_metas = self.request.files.get(
            'file', None)  # 提取表单中‘name’为‘file’的文件元数据

        if not file_metas:
            ret['result'] = 'Invalid Args'
            return ret

        for meta in file_metas:
            filename = meta['filename']
            file_path = '/home/sning/Downloads/' + filename

            with open(file_path, 'wb') as up:
                up.write(meta['body'])

        self.write(json.dumps(ret))


class ImageHandler(RequestHandler):

    def post(self):
        # 图片上传功能代码
        file_metas = self.request.files.get(
            'upload', None)  # 提取表单中‘name’为‘file’的文件元数据
        filename = ''
        for meta in file_metas:
            filename = meta['filename']
            file_path = '/home/sning/MyFile/P_L/Python3/myweb/static/blog_img/' + filename

            with open(file_path, 'wb') as up:
                up.write(meta['body'])
            print('save finish')
        print("file")
        json_res = {
            "uploaded": True,
            "url": 'static/blog_img/' + filename
        }
        self.write(json_res)
        self.flush()


class CreateHandler(RequestHandler):

    def post(self):
        u_id = str(self.get_argument('u_id'))
        title = str(self.get_argument('title'))
        key_words = str(self.get_argument('key_words'))
        category = str(self.get_argument('category'))
        image_url = str(self.get_argument('image_url'))
        summary = str(self.get_argument('summary'))
        content = str(self.get_argument('content'))
        if(createart(u_id, title, summary, key_words, category, image_url, content)):
            print("articles insert finish")
        else:
            self.set_status(201)
            self.flush()
