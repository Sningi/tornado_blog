#!/usr/bin/env Python
# coding=utf-8
"""
the url structure of website
"""

from handlers.html import HtmlHandler
from handlers.resource import ResourceHandler, FileHandler, ImageHandler, CreateHandler

url = [
    (r"/", HtmlHandler),
    (r"/.+?\.html", HtmlHandler),
    (r"/file", FileHandler),
    (r"/createart", CreateHandler),
    (r"/uploadImages", ImageHandler),
    (r"/data.+?", ImageHandler),
    # (r".+?", ResourceHandler)
]
